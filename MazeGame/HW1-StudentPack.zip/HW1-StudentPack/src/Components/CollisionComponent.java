package Components;

import Util.AABB;

import java.util.ArrayList;

public class CollisionComponent implements IRealTimeComponent, ICollisionListener {
    public ArrayList<AABB> Observers;

    public CollisionComponent(){
        Observers = new ArrayList<>();
    }
    // TODO:
    @Override
    public void update(float deltaT)
    {
        // TODO:
    }

    @Override
    public void addObserver(AABB x) {
        Observers.add(x);
    }

    @Override
    public void removeObserver(AABB x) {
        int i = Observers.indexOf(x);
        if (i >= 0) {
            Observers.remove(i);
        }
    }

    @Override
    public ArrayList<AABB> aCollisionIsHappened() {
        ArrayList<AABB> collider = new ArrayList<>();
        for (int i = 0; i < Observers.size(); i++){
            for (int j = i+1; j < Observers.size(); j++){
                if(Observers.get(i).moveIfCollide(Observers.get(j))){
                    collider.add(Observers.get(i));
                    collider.add(Observers.get(j));
                    return collider;
                }
            }
        }
        return collider;
    }
}
