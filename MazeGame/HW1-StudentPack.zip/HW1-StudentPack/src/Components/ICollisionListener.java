package Components;

import Util.AABB;

import java.util.ArrayList;

public interface ICollisionListener
{
    // You can change the interface here (add arguments to the function or
    // change the name etc.)
    public void addObserver(AABB x);
    public void removeObserver(AABB x);
    public ArrayList<AABB> aCollisionIsHappened();
}
