package Components;

import Util.Position2D;

public class VerticalPatrolStrategy extends AbstractPatrolStrategy
{
    // TODO:

    @Override
    public void update(float deltaT)
    {
        // TODO:
    }
}
