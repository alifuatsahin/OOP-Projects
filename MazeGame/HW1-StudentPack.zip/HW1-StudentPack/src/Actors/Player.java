package Actors;

import Components.SpriteComponent;
import Util.Position2D;

import java.awt.*;
import java.io.IOException;

public class Player extends AbstractActor
{
    protected SpriteComponent player;
    public float pSpeed = 110;
    /**
     * Constructor, directly sets the every parameter
     *
     * @param pos "top right" (wrt. the screen coordinates) of the box
     * @param szX horizontal size of the box in pixels
     * @param szY vertical size of the box in pixels
     */
    public Player(Position2D<Float> pos, float szX, float szY) throws IOException {
        super(pos, szX, szY);
        this.player = new SpriteComponent("./data/img/player.png");
    }
    // TODO:

    @Override
    public void update(float deltaT, Graphics2D g)
    {
        player.draw(g, super.newActor);
        // TODO: or delete
    }

    @Override
    public boolean isDead()
    {
        // TODO:
        return false;
    }

    @Override
    public void update(float deltaT) {

    }
}
