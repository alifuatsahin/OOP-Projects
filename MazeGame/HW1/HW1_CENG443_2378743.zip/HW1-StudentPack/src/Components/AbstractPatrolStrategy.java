package Components;

import Actors.Enemy;

public abstract class AbstractPatrolStrategy implements IRealTimeComponent
{
    // TODO:
    protected Enemy enemy;
    @Override
    public void update(float deltaT)
    {
        // TODO:
    }
}
